const express = require('express');
const db = require('./database/db');

const PORT = 8080;

const server = express();

let getCounter = 0;
let postCounter = 0;
let putCounter = 0;
let deleteCounter = 0;



// Set the header
server.use(function (req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE, OPTIONS');
  res.header(
    'Access-Control-Allow-Headers',
    'Content-Type, Authorization, Content-Length, X-Requested-With'
  );
  next();
});

server.use(express.json());
server.use(express.urlencoded({ extended: false }));

server.get('/termProject/api/quoteBank', function (req, res) {
    getCounter++;

  db.getQuotes(function (data) {
    try {
      if (data) res.status(200).json({ data: data });
    } catch (error) {
      res.status(400).json({ msg: 'Could not fetch the quotes' });
    }
  });
});

server.post('/termProject/api/quoteBank', function (req, res) {
    postCounter++;
  db.insertQuote(req.body, function (data) {
    try {
      if (data != undefined || data) {
        res.status(200).json({ msg: 'Quote successfully created!' });
      }
    } catch (error) {
      res.status(400).json({ msg: 'Could not fetch the quotes' });
    }
  });
});

server.put('/termProject/api/quoteBank/:id', function (req, res) {
    putCounter++;
  db.updateQuote(req.params.id, req.body, function (data) {
    try {
      if (data != undefined || data) {
        res.status(200).json({ msg: 'Quote successfully updated!' });
      }
    } catch (error) {
      res.status(400).json({ msg: 'Could not fetch the quotes' });
    }
  });
});

server.delete('/termProject/api/quoteBank/:id', function (req, res) {
    deleteCounter++;
  db.deleteQuote(req.params.id, function (data) {
    try {
      if (data != undefined || data) {
        res.status(200).json({ msg: 'Quote successfully deleted!' });
      }
    } catch (error) {
      res.status(400).json({ msg: 'Could not fetch the quotes' });
    }
  });
});


server.get('/termProject/api/quoteBank/counter', function (req, res) {
    getCounter++;
    let obj = { gc: getCounter, poc: postCounter,  puc: putCounter,  dc: deleteCounter };
    let countJSON = JSON.stringify(obj);
    
    try {
   //   if (data) res.status(200).json({ data: data });
        res.send(countJSON);
    } catch (error) {
      res.status(400).json({ msg: 'Could not fetch the quotes' });
    }
});

server.listen(PORT, console.log(`Server is listening on PORT ${PORT}`));